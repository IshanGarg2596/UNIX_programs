// 1. sort linked list in descending order
// 2. reverse the linked list without recursion
#include <iostream>
#include "LinkedList.h"
using namespace std;

void linkedList::reverse(){
    struct node* curr = List;
    struct node* next = NULL;
    struct node* prev = NULL;
        
    while(curr != NULL){
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    } 
    List = prev;
}

void linkedList::sort(){
	struct node* i = List;
    while(i != NULL){
        struct node* max = i;
        struct node* j = i;
		while(j != NULL){
			if(j->data > max->data){
				max = j;
			}
			j = j->next;
		}
		int temp = max-> data;
		max->data = i->data;
		i->data = temp;  
		i = i->next;
    }
}

int main(){
    linkedList L;

    int e, n;
    cout << "Enter no of elements: ";
    cin >> n;
    cout<<"Enter elements of list:";
    for(int i = 0; i < n; i++){
        cin >> e;
        L.insertBack(e);
    }
    cout << "Reversed Linked List:" << "\n";
    L.reverse();
    L.printList();
    cout << "Sorted Linked List:" << "\n";
    L.sort();
    L.printList();
    cout<<"\n";
    return 0;
}